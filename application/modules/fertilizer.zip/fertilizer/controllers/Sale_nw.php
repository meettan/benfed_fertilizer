<?php
	class Sale extends MX_Controller{
		protected $sysdate;
		protected $kms_year;
		public function __construct(){
		parent::__construct();	
		$this->load->model('SaleModel');
		// $this->load->helper('paddyrate_helper');
		// $data       = $this->FertilizerModel->f_get_particulars_in('md_parameters', array(16, 17), array(""));

		// $this->kms_year   = substr($data[0]->param_value, 0,4).'-'.substr($data[1]->param_value, 2,2);
		$this->session->userdata('fin_yr');
		}
		
	
		public function js_get_stock_qty()
		{

			$ro = $this->input->get('ro');
			// var_dump($ro);die;
			$result = $this->SaleModel->js_get_stock_qty($ro);
			
 			echo json_encode($result);

		} 
		
		public function sale(){
			$br_cd      = $this->session->userdata['loggedin']['branch_id'];
			$fin_id=$this->session->userdata['loggedin']['fin_id'];
			
			$bank['data']    = $this->SaleModel->f_get_sales_dtls($br_cd,$fin_id);
	// 		echo $this->db->last_query();
	// die();
		   $this->load->view("post_login/fertilizer_main");
	   
		   $this->load->view("sale/dashboard",$bank);
	   
		   $this->load->view('search/search');
	   
		   $this->load->view('post_login/footer');
	   }


public function saleAdd(){
	
	$br_cd      = $this->session->userdata['loggedin']['branch_id'];
	$dist_sort_code    = $this->session->userdata['loggedin']['dist_sort_code'];
	$fin_year_sort_code=substr($this->session->userdata['loggedin']['fin_yr'],2);
	$fin_id=$this->session->userdata['loggedin']['fin_id'];
	$trans_no = $this->SaleModel->get_trans_no($fin_id,$br_cd);

	// echo $fin_year_sort_code;
	// die();
	// echo $this->db->last_query();
	// die();
	if($_SERVER['REQUEST_METHOD'] == "POST") {
		
			$prod_id = $this->input->post('prod_id');

			$qty = $this->input->post('qty');

			$sale_rt = $this->input->post('sale_rt');
				
			$taxable_amt= $this->input->post('taxable_amt');

			$cgst=$this->input->post('cgst');

			$sgst=$this->input->post('sgst');

			$tot_amt=$this->input->post('tot_amt');

			$br_cd      = $this->session->userdata['loggedin']['branch_name'];
			// echo ($prod_id);
			//    die();
			  for($i = 0; $i < count($prod_id); $i++){
			   
			   $data     = array(
									'trans_do' =>  'SRO/'.$dist_sort_code.'/'.$fin_year_sort_code.'/'. $trans_no->trans_no,
								   
									'trans_no'  =>  $trans_no->trans_no ,
									 
                                    'do_dt'        => $this->input->post('ro_dt'),

                                    'sale_due_dt'  => $this->input->post('sale_due_dt'),

                                    'trans_type'   => $this->input->post('trans_type'),

                                    'soc_id'       => $this->input->post('soc_id'),
									
									'comp_id'      => $this->input->post('comp_id'),

                                    'sale_ro'      => $_POST['ro'][$i],

                                    'prod_id'      => $_POST['prod_id'][$i],
                                                            
                                    'qty'          => $_POST['qty'][$i],

                                    'sale_rt'      => $_POST['sale_rt'][$i],

                                    'taxable_amt'  => $_POST['taxable_amt'][$i],

                                    'cgst'         => $_POST['cgst'][$i],

                                    'sgst'        => $_POST['sgst'][$i],

                                    'dis'        => $_POST['dis'][$i],

                                    'tot_amt'     => $_POST['tot_amt'][$i],

                                    "created_by"    =>  $this->session->userdata['loggedin']['user_name'],

					                "created_dt"    =>  date('Y-m-d h:i:s'),

									 "br_cd"     => $this->session->userdata['loggedin']['branch_id'],

									 "fin_yr"    => $fin_id
                                );
								
		
		
				$this->SaleModel->f_insert('td_sale', $data);

			}
				
				$this->session->set_flashdata('msg', 'Successfully Added');

					redirect('trade/sale');
		
           
            
			}else {
				$select3          = array("comp_id","comp_name");
				$product['compdtls']   = $this->SaleModel->f_select('mm_company_dtls',$select3,NULL,0);	
				
				// $where  =   array(

				// 	'comp_id'     => $this->input->post('comp_id'));
				$select2         = array("ro_no","qty");
				$where  =   array(

					'br'     => $br_cd);
					
				$product['rodtls']   = $this->SaleModel->f_select('td_purchase',$select2,$where,0);
// echo $this->db->last_query();
// die();
				$select1          = array("soc_id","soc_name","soc_add","gstin");
				$where1  =   array(

					'district'     => $br_cd);
				$product['socdtls']   = $this->SaleModel->f_select('mm_ferti_soc',$select1,$where1,0);

				$select          = array("prod_id","prod_desc","gst_rt");
				$product['proddtls']   = $this->SaleModel->f_select('mm_product',$select,NULL,0);	

	$this->load->view('post_login/fertilizer_main');

	$this->load->view("sale/add",$product);

	$this->load->view('post_login/footer');
}

}

     public function saleedit(){


	if($_SERVER['REQUEST_METHOD'] == "POST") {

            	$prod_id = $this->input->post('prod_id');
				
				
			  for($i = 0; $i < count($prod_id); $i++){

			  $data     = array(
                                  'do_dt'        => $this->input->post('ro_dt'),

								   'sale_due_dt'  => $this->input->post('sale_due_dt'), 

								   'comp_id'  => $this->input->post('comp_id'),

                                   'sale_ro'      => $_POST['ro'][$i],

                                    'prod_id'      => $_POST['prod_id'][$i],

                                    'qty'          => $_POST['qty'][$i],

                                    'sale_rt'      => $_POST['sale_rt'][$i],

									'taxable_amt'  => $_POST['taxable_amt'][$i],
									
									'gst_rt'        => $_POST['gst_rt'][$i],
									
                                    'cgst'         => $_POST['cgst'][$i],

                                    'sgst'        => $_POST['sgst'][$i],

                                    'tot_amt'     => $_POST['tot_amt'][$i],

                                    "modified_by"  =>  $this->session->userdata['loggedin']['user_name'],

				                    "modified_dt"    =>  date('Y-m-d h:i:s'),

                                );

		   $where  =   array(

                 'trans_do'     => $this->input->post('trans_do'),

                 'sale_ro'      => $_POST['ro'][$i]

            );

            $this->SaleModel->f_edit('td_sale', $data, $where);
							}
				
				$this->session->set_flashdata('msg', 'Successfully Updated');

			redirect('fertilizer/sale');
		
           
            
			}else {
				// $comp_id	= $this->input->post('comp_id');
				// echo $comp_id;
				// die();
				$select3        = array("comp_id","comp_name");
				$product['compdtls']   = $this->SaleModel->f_select('mm_company_dtls',$select3,NULL,0);

				$where  =   array(

					'comp_id'     => $this->input->get('comp_id'));
					
				$select2         = array("ro_no","qty");

				$product['rodtls']   = $this->SaleModel->f_select('td_purchase',$select2,NULL,0);
			// echo $this->db->last_query();
			// die();
			$select1          = array("soc_id","soc_name","soc_add","gstin");
			$product['socdtls']   = $this->SaleModel->f_select('mm_ferti_soc',$select1,NULL,0);

			$select          = array("prod_id","prod_desc","gst_rt");
			$product['proddtls']   = $this->SaleModel->f_select('mm_product',$select,NULL,0);	
            $product['prod_dtls']  = $this->SaleModel->f_get_particulars("td_sale", NULL, array( "trans_do" => $this->input->get('trans_do')),0);
		//    echo $this->db->last_query();
		//    die();
	        $this->load->view('post_login/fertilizer_main');

	       $this->load->view("sale/edits",$product);

	        $this->load->view('post_login/footer');
}

}
	
public function deletesale() {

	$where = array(
				 "trans_do"    =>  $this->input->get('trans_do')
				
		
	);
$this->SaleModel->f_delete('td_sale', $where);

$this->session->set_flashdata('msg', 'Successfully Deleted!');

redirect("fertilizer/fertilizer/sale");

}

//***************************/
		public function f_get_ro()
        {

            $ro_no = $this->input->get('ro_no');
           
			$data = $this->FertilizerModel->f_get_ro_dtls($ro_no);
			// echo $this->db->last_query();
			// die();
            echo json_encode($data);

		}
		
		public function deleteinvoice() {

			$where = array(
						 "ro"    =>  $this->input->get('ro_no')
						
				
			);
		$this->FertilizerModel->f_delete('td_invoice_entry', $where);
	
		$this->session->set_flashdata('msg', 'Successfully Deleted!');
		
		redirect("fertilizer/fertilizer/invoice_entry");
	
	}


		public function f_get_company(){

			$select          = array("gst_no","comp_add","cin");
			
		   $where=array(
			   "comp_id" =>$this->input->get("comp_id")
			   ) ;
		
			   
			$comp    = $this->FertilizerModel->f_select('mm_company_dtls',$select,$where,0);
			// echo $this->db->last_query();
			// die();
			echo json_encode($comp);
		
		}
		public function f_get_soc(){

			$select          = array("soc_id","soc_add","gstin");
			
		   $where=array(
			   "soc_id" =>$this->input->get("soc_id")
			   ) ;
		
			   
			$soc    = $this->SaleModel->f_select('mm_ferti_soc',$select,$where,0);
			// echo $this->db->last_query();
			// die();
			echo json_encode($soc);
		
		}
		public function f_get_hsn(){

			$select          = array("hsn_code","gst_rt");
			
		   $where=array(
			   "prod_id" =>$this->input->get("prod_id")
			   ) ;
		
			   
			$prod    = $this->FertilizerModel->f_select(' mm_product',$select,$where,0);
			// echo $this->db->last_query();
			// die();
			echo json_encode($prod);
		
		}

		public function f_get_qty_per_bag(){

			$select          = array("qty_per_bag");
			
		   $where=array(
			   "prod_id" =>$this->input->get("prod_id")
			   ) ;
		
			   
			$prod    = $this->FertilizerModel->f_select(' mm_product',$select,$where,0);
			// echo $this->db->last_query();
			// die();
			echo json_encode($prod);
		
		}	
//View Stock RO

public function f_get_product(){

	$select          = array("prod_id","prod_desc");
	
   $where=array(
	   "company" =>$this->input->get("comp_id")
	   ) ;

	$product    = $this->FertilizerModel->f_select(' mm_product',$select,$where,0);

    echo json_encode($product);

}

public function f_get_sale_ro(){
	// echo 'hi';
	// die();
    $select = array("a.ro_no " );
       		
			$where      =   array(

			"a.comp_id = b.comp_id"  => NULL,
			"a.comp_id"    =>  $this->input->get('comp_id')
                );
			   
			$ro   = $this->SaleModel->f_select('td_purchase a,mm_company_dtls b',$select,$where,0);
			
			// echo $this->db->last_query();
			// die();
			echo json_encode($ro);

	        }

public function deletero() {

	$where = array(
				 "ro_no"    =>  $this->input->get('ro_no'),
				 "challan_flag" =>  'N'
		
	);
	
	$this->FertilizerModel->f_delete('td_purchase', $where);

	$select1          = array("challan_flag");
	$where = array(
		"ro_no"    =>  $this->input->get('ro_no'));

$challan_flag = $this->FertilizerModel->f_select('td_purchase',$select1,$where,0);

	$this->session->set_flashdata('msg', 'Successfully Deleted!');
	
	redirect("fertilizer/fertilizer/stock_entry");

}

	// code for Sale Report Developed by lokesh 02/04/2020 ////	
      public function sale_report(){

			if($_SERVER['REQUEST_METHOD']=="POST"){

				 //Retriving CMR delivery Details
                $select     =   array(

               "a.do_dt", "a.qty", "a.tot_amt",

                "c.COMP_NAME", "b.PROD_DESC"

               );

             $where      =   array(

            "a.prod_id = b.PROD_ID"  => NULL,

            "b.COMPANY = c.COMP_ID"  => NULL,

                );
			$row['sales']=$this->FertilizerModel->f_select('td_sale a,mm_product b,mm_company_dtls c',$select,$where,0);

				$this->load->view('post_login/fertilizer_main');
				$this->load->view('report/sale_re',$row);
				$this->load->view('post_login/footer');
						
			}else{
			
				$this->load->view('post_login/fertilizer_main');
				$this->load->view('report/sale_re');
				$this->load->view('post_login/footer');
			}	
		}

        // code for Sale Districtwise Report Developed by lokesh 02/04/2020 ////	

		  public function sale_reportdis(){

			if($_SERVER['REQUEST_METHOD']=="POST"){

				$where = array(
               
				);

				 //Retriving CMR delivery Details
                $select     =   array(

               "a.do_dt", "a.qty", "a.tot_amt",

                "c.COMP_NAME", "b.PROD_DESC"

               );

             $where      =   array(

            "a.prod_id = b.PROD_ID"  => NULL,

            "b.COMPANY = c.COMP_ID"  => NULL,

            "a.br_cd" => $this->input->post('branch_id')

                );
			$row['sales']=$this->FertilizerModel->f_select('td_sale a,mm_product b,mm_company_dtls c',$select,$where,0);

				$this->load->view('post_login/fertilizer_main');
				$this->load->view('report/sale_redis',$row);
				$this->load->view('post_login/footer');
						
			}else{
			$row['districts']=$this->FertilizerModel->f_select('md_district',NULL,NULL,0);
				$this->load->view('post_login/fertilizer_main');
				$this->load->view('report/sale_redis',$row);
				$this->load->view('post_login/footer');
			}	
		}	


	
	}
?>
